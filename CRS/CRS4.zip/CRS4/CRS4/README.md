# Car-Rentals-Web-Application
We created project Cars booking system using HTML,CSS (for frontend) PHP (for backend) and SQL,PLSQL for (database management) in group of three (Saurabh(myself),Sumeet and Prashant)
